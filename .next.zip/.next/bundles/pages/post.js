
          window.__NEXT_REGISTER_PAGE('/post', function() {
            var comp = module.exports=webpackJsonp([6],{481:function(e,t,u){e.exports=u(482)},482:function(e,t,u){"use strict";function l(e){return e&&e.__esModule?e:{default:e}}Object.defineProperty(t,"__esModule",{value:!0});var n=u(3),r=l(n),a=u(140),o=l(a);t.default=function(e){return r.default.createElement(o.default,null,r.default.createElement("h1",null,e.url.query.id),r.default.createElement("p",null,"This is the post page."))}}},[481]);
            return { page: comp.default }
          })
        